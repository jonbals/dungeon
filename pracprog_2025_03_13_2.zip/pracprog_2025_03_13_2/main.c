#include <stdio.h>
#include <stdlib.h>
#include <conio.h>


#define GRID_WIDTH 40
#define GRID_HEIGHT 24
#define GRID_SIZE (GRID_WIDTH * GRID_HEIGHT)

#define MAX_TILE_ACTIONS 1024


enum GAME_STATES
{
    GAME_STATE_OVERWORLD,
    GAME_STATE_FIGHT,
    NUM_GAME_STATES
};


enum ENUM_TILES
{
    TILE_AIR,
    TILE_WALL,
    TILE_PLAYER,
    TILE_ENEMY,
    NUM_TILES
};


typedef struct {
    const char* icon;
} tile_t;


typedef struct {
    int data[GRID_SIZE];
} scene_t;


typedef struct {
    int tile_x;
    int tile_y;
    int move_x;
    int move_y;
    int change_tile_id;
} tile_action_t;


void clearScene(scene_t* scene)
{
    for(int i = 0; i < GRID_SIZE; i++)
    {
        scene->data[i] = TILE_AIR;
    }
}


int getTileId(scene_t* scene, int x, int y)
{
    return scene->data[x + (GRID_WIDTH * y)];
}


void setTile(scene_t* scene, int x, int y, int tile_id)
{
    scene->data[x + (GRID_WIDTH * y)] = tile_id;
}


void renderScene(scene_t* scene, tile_t* tiles)
{
    for(int y = 0; y < GRID_HEIGHT; y++)
    {
        for(int x = 0; x < GRID_WIDTH; x++)
        {
            printf(tiles[getTileId(scene, x, y)].icon);
        }
        printf("\n");
    }
}


void makeRoom(scene_t* scene, int pos_x, int pos_y, int width, int height)
{
    for(int y = pos_y; y < pos_y + height; y++)
    {
        for(int x = pos_x; x < pos_x + width; x++)
        {
            if(x == pos_x || x == pos_x + width - 1 || y == pos_y || y == pos_y + height - 1)
            {
                setTile(scene, x, y, TILE_WALL);
            }
        }
    }
}


void makeHallway(scene_t* scene, int from_x, int from_y, int to_x, int to_y)
{
    int stage = 0;
    while(stage < 2)
    {
        int cur_x = from_x;
        int cur_y = from_y;

        int d_x = 0;
        int d_y = 0;

        while(cur_x != to_x || cur_y != to_y)
        {
            if(cur_x < to_x) {
                d_x = 1;
                d_y = 0;
            } else if(cur_x > to_x) {
                d_x = -1;
                d_y = 0;
            } else if(cur_y < to_y) {
                d_x = 0;
                d_y = 1;
            } else if(cur_y > to_y) {
                d_x = 0;
                d_y = -1;
            }

            if(stage == 0)
            {
                for(int i = -1; i <= 1; i++)
                {
                    for(int j = -1; j <= 1; j++)
                    {
                        setTile(scene, cur_x + i, cur_y + j, TILE_WALL);
                    }
                }
                if(cur_x == from_x && cur_y == from_y) {
                    setTile(scene, cur_x - d_x, cur_y - d_y, TILE_AIR);
                } else if((cur_x + d_x) == to_x && (cur_y + d_y) == to_y) {
                    setTile(scene, cur_x + d_x, cur_y + d_y, TILE_AIR);
                }
            }
            else if(stage == 1)
            {
                setTile(scene, cur_x, cur_y, TILE_AIR);
            }

            cur_x += d_x;
            cur_y += d_y;
        }
        stage++;
    }
}


int main()
{
    int cur_game_state = GAME_STATE_OVERWORLD;

    // overworld stuff

    tile_t tiles[NUM_TILES];
    tiles[TILE_AIR].icon = "  ";
    tiles[TILE_WALL].icon = "[]";
    tiles[TILE_PLAYER].icon = "$@";
    tiles[TILE_ENEMY].icon = "#%%";

    scene_t scene;
    clearScene(&scene);

    makeRoom(&scene, 1, 1, 12, 8);
    makeRoom(&scene, 17, 15, 18, 6);
    makeRoom(&scene, 28, 5, 10, 8);
    makeRoom(&scene, 3, 10, 12, 10);
    makeHallway(&scene, 13, 4, 20, 15);
    makeHallway(&scene, 22, 8, 28, 8);
    makeHallway(&scene, 15, 12, 19, 12);

    setTile(&scene, 4, 4, TILE_PLAYER);
    setTile(&scene, 7, 5, TILE_ENEMY);

    // fight stuff

    const char* enemy_sprite =
        " ^-^   \\\n"
        "(O,O)_||\n"
        " | ___ |\n"
        " ||   ||";

    // game loop

    char input = ' ';
    while(input != 'q')
    {

        // update

        if(cur_game_state == GAME_STATE_OVERWORLD)
        {
            tile_action_t tile_actions[MAX_TILE_ACTIONS];
            int tile_action_counter = 0;
            for(int i = 0; i < MAX_TILE_ACTIONS; i++)
            {
                tile_actions[i].tile_x = -1;
                tile_actions[i].tile_y = -1;
                tile_actions[i].move_x = 0;
                tile_actions[i].move_y = 0;
                tile_actions[i].change_tile_id = -1;
            }

            int p_x = 0;
            int p_y = 0;

            switch(input)
            {
                case 'w':
                    p_y = -1;
                    break;
                case 'a':
                    p_x = -1;
                    break;
                case 's':
                    p_y = 1;
                    break;
                case 'd':
                    p_x = 1;
                    break;
            }

            for(int y = 0; y < GRID_HEIGHT; y++)
            {
                for(int x = 0; x < GRID_WIDTH; x++)
                {
                    if(getTileId(&scene, x, y) == TILE_PLAYER)
                    {
                        tile_actions[tile_action_counter].tile_x = x;
                        tile_actions[tile_action_counter].tile_y = y;
                        tile_actions[tile_action_counter].move_x = p_x;
                        tile_actions[tile_action_counter].move_y = p_y;
                    }
                }
            }

            for(int i = 0; i < MAX_TILE_ACTIONS; i++)
            {
                tile_action_t* ta = &tile_actions[i];
                if(ta->tile_x == -1 || ta->tile_y == -1)
                {
                    break;
                }

                if(ta->move_x != 0 || ta->move_y != 0)
                {
                    int tile_id = getTileId(&scene, ta->tile_x, ta->tile_y);
                    int new_x = ta->tile_x + ta->move_x;
                    int new_y = ta->tile_y + ta->move_y;

                    int colliding_tile_id = getTileId(&scene, new_x, new_y);
                    if(colliding_tile_id == TILE_WALL) continue;
                    else if(colliding_tile_id == TILE_ENEMY)
                    {
                        cur_game_state = GAME_STATE_FIGHT;
                    }

                    setTile(&scene, new_x, new_y, tile_id);
                    setTile(&scene, ta->tile_x, ta->tile_y, TILE_AIR);
                }
            }
        }
        else if(cur_game_state == GAME_STATE_FIGHT)
        {

        }

        // render
        if(cur_game_state == GAME_STATE_OVERWORLD)
        {
            renderScene(&scene, tiles);
        }
        else if(cur_game_state == GAME_STATE_FIGHT)
        {
            printf(enemy_sprite);
        }

        input = getch();
        system("cls");
    }

    return 0;
}
