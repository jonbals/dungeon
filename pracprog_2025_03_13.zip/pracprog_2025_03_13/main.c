#include <stdio.h>
#include <stdlib.h>
#include <conio.h>


#define GRID_WIDTH 40
#define GRID_HEIGHT 24
#define GRID_SIZE (GRID_WIDTH * GRID_HEIGHT)


enum ENUM_TILES
{
    TILE_AIR,
    TILE_WALL,
    TILE_PLAYER,
    NUM_TILES
};


typedef struct {
    const char* icon
} tile_t;


typedef struct {
    int data[GRID_SIZE];
} scene_t;


void clearScene(scene_t* scene)
{
    for(int i = 0; i < GRID_SIZE; i++)
    {
        scene->data[i] = TILE_AIR;
    }
}


int getTileId(scene_t* scene, int x, int y)
{
    return scene->data[x + (GRID_WIDTH * y)];
}


void setTile(scene_t* scene, int x, int y, int tile_id)
{
    scene->data[x + (GRID_WIDTH * y)] = tile_id;
}


void renderScene(scene_t* scene, tile_t* tiles)
{
    for(int y = 0; y < GRID_HEIGHT; y++)
    {
        for(int x = 0; x < GRID_WIDTH; x++)
        {
            printf(tiles[getTileId(scene, x, y)].icon);
        }
        printf("\n");
    }
}


void makeRoom(scene_t* scene, int pos_x, int pos_y, int width, int height)
{
    for(int y = pos_y; y < pos_y + height; y++)
    {
        for(int x = pos_x; x < pos_x + width; x++)
        {
            if(x == pos_x || x == pos_x + width - 1 || y == pos_y || y == pos_y + height - 1)
            {
                setTile(scene, x, y, TILE_WALL);
            }
        }
    }
}


void makeHallway(scene_t* scene, int from_x, int from_y, int to_x, int to_y)
{
    int stage = 0;
    while(stage < 2)
    {
        int cur_x = from_x;
        int cur_y = from_y;

        int d_x = 0;
        int d_y = 0;

        while(cur_x != to_x || cur_y != to_y)
        {
            if(cur_x < to_x) {
                d_x = 1;
                d_y = 0;
            } else if(cur_x > to_x) {
                d_x = -1;
                d_y = 0;
            } else if(cur_y < to_y) {
                d_x = 0;
                d_y = 1;
            } else if(cur_y > to_y) {
                d_x = 0;
                d_y = -1;
            }

            if(stage == 0)
            {
                for(int i = -1; i <= 1; i++)
                {
                    for(int j = -1; j <= 1; j++)
                    {
                        setTile(scene, cur_x + i, cur_y + j, TILE_WALL);
                    }
                }
                if(cur_x == from_x && cur_y == from_y) {
                    setTile(scene, cur_x - d_x, cur_y - d_y, TILE_AIR);
                } else if((cur_x + d_x) == to_x && (cur_y + d_y) == to_y) {
                    setTile(scene, cur_x + d_x, cur_y + d_y, TILE_AIR);
                }
            }
            else if(stage == 1)
            {
                setTile(scene, cur_x, cur_y, TILE_AIR);
            }

            cur_x += d_x;
            cur_y += d_y;
        }
        stage++;
    }
}


int main()
{
    tile_t tiles[NUM_TILES];
    tiles[TILE_AIR].icon = "  ";
    tiles[TILE_WALL].icon = "[]";
    tiles[TILE_PLAYER].icon = "$@";

    scene_t scene;
    clearScene(&scene);

    makeRoom(&scene, 1, 1, 12, 8);
    makeRoom(&scene, 17, 15, 18, 6);
    makeRoom(&scene, 28, 5, 10, 8);
    makeRoom(&scene, 3, 10, 12, 10);
    makeHallway(&scene, 13, 4, 20, 15);
    makeHallway(&scene, 22, 8, 28, 8);
    makeHallway(&scene, 15, 12, 19, 12);

    setTile(&scene, 4, 4, TILE_PLAYER);

    char input = ' ';
    while(input != 'q')
    {
        system("cls");
        renderScene(&scene, tiles);
        input = getch();
    }

    return 0;
}
